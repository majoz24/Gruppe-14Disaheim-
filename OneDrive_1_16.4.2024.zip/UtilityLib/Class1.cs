﻿namespace UtilityLib
{
    public class Class1
    {

    }
}
